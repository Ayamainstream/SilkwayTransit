package com.example.silkwaytransit.ui.home.duty;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import com.example.silkwaytransit.R;
import com.example.silkwaytransit.network.duty.Drivers;

import java.util.ArrayList;

public class DutyLVAdapter extends ArrayAdapter<Drivers> {

    public DutyLVAdapter(@NonNull Context context, ArrayList<Drivers> dataModalArrayList) {
        super(context, 0, dataModalArrayList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listitemView = convertView;
        if (listitemView == null) {
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.listview_layout, parent, false);
        }

        Drivers dataModal = getItem(position);

        TextView driverName = listitemView.findViewById(R.id.driverName);
        TextView status = listitemView.findViewById(R.id.status);

        driverName.setText(dataModal.getFullName());
        if (dataModal.getStatus() == true) {
            status.setText("Активный");
        }else {
            status.setText("Не активный");
        }

        listitemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Item clicked is : " + dataModal.getFullName(), Toast.LENGTH_SHORT).show();
            }
        });
        return listitemView;
    }
}

