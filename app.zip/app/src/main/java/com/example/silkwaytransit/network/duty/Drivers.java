package com.example.silkwaytransit.network.duty;

public class Drivers {
    private String FullName;
    private Boolean Status;

    public Drivers(){}

    public Drivers(String fullName, Boolean status){
        this.FullName = fullName;
        this.Status = status;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        this.FullName = fullName;
    }

    public Boolean getStatus() {
        return Status;
    }

    public void setStatus(Boolean status) {
        Status = status;
    }

    @Override
    public String toString() {
        return "Drivers{" +
                "FullName='" + FullName + '\'' +
                ", Status=" + Status +
                '}';
    }
}
